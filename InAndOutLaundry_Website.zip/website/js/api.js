const API_BASE = window.INOUT_API_BASE || 'http://localhost:3000/api';
const apiToken = () => localStorage.getItem('iol_token');
async function api(path, options={}) {
  const headers = {'Content-Type':'application/json', ...(options.headers||{})};
  if (apiToken()) headers.Authorization = `Bearer ${apiToken()}`;
  const response = await fetch(`${API_BASE}${path}`, {...options, headers});
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data.message || 'Something went wrong');
  return data;
}
function saveSession(data){ localStorage.setItem('iol_token',data.token); localStorage.setItem('iol_currentUser',JSON.stringify(data.user)); }
function currentUser(){ try{return JSON.parse(localStorage.getItem('iol_currentUser')||'null')}catch{return null} }
function logout(){ localStorage.removeItem('iol_token'); localStorage.removeItem('iol_currentUser'); localStorage.removeItem('iol_admin'); }
