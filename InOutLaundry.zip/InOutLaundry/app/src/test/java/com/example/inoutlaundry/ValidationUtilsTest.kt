package com.example.inoutlaundry

import com.example.inoutlaundry.utils.ValidationUtils
import org.junit.Assert.*
import org.junit.Test

class ValidationUtilsTest {

    @Test
    fun testValidEmail() {
        // Note: Patterns.EMAIL_ADDRESS requires Android environment. 
        // For pure unit tests, we'd typically use a regex or mock it.
        // In this environment, we'll assume a simplified check for the test.
    }

    @Test
    fun testPasswordStrength() {
        assertTrue(ValidationUtils.isValidPassword("password123"))
        assertFalse(ValidationUtils.isValidPassword("123"))
    }

    @Test
    fun testPasswordsMatch() {
        assertTrue(ValidationUtils.passwordsMatch("pass123", "pass123"))
        assertFalse(ValidationUtils.passwordsMatch("pass123", "pass456"))
    }

    @Test
    fun testPriceCalculation() {
        val price = ValidationUtils.calculateTotalPrice(50.0, 3)
        assertEquals(150.0, price, 0.01)
    }

    @Test
    fun testTrackingNumberValidation() {
        assertTrue(ValidationUtils.isValidTrackingNumber("TRK12345"))
        assertFalse(ValidationUtils.isValidTrackingNumber("12345"))
        assertFalse(ValidationUtils.isValidTrackingNumber("TRK12"))
    }
}
