package com.example.inoutlaundry.ui.tracking

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.inoutlaundry.ui.theme.PrimaryBlue
import com.example.inoutlaundry.viewmodel.LaundryViewModel

@Composable
fun TrackingScreen(
    viewModel: LaundryViewModel,
    initialTrackingNumber: String = ""
) {
    var trackingNumber by remember { mutableStateOf(initialTrackingNumber) }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(scrollState)
    ) {
        Text("Track Your Laundry", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = trackingNumber,
            onValueChange = { trackingNumber = it },
            label = { Text("Enter Tracking Number") },
            modifier = Modifier.fillMaxWidth(),
            trailingIcon = {
                IconButton(onClick = { /* Trigger search */ }) {
                    Icon(Icons.Default.Search, contentDescription = "Search")
                }
            }
        )

        Spacer(modifier = Modifier.height(32.dp))

        if (trackingNumber.isNotEmpty()) {
            TrackingTimeline(trackingNumber)
        } else {
            Box(modifier = Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                Text("Enter a tracking number to see status", color = Color.Gray)
            }
        }
    }
}

@Composable
fun TrackingTimeline(trackingNumber: String) {
    val stages = listOf(
        "Booking Received",
        "Pickup Scheduled",
        "Laundry Collected",
        "Washing / Processing",
        "Ready for Delivery",
        "Out for Delivery",
        "Delivered"
    )
    val currentStageIndex = 3 // Simulated current stage

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("Order status for #$trackingNumber", fontWeight = FontWeight.Bold, color = PrimaryBlue)
            Spacer(modifier = Modifier.height(24.dp))

            stages.forEachIndexed { index, stage ->
                TimelineItem(
                    title = stage,
                    isCompleted = index < currentStageIndex,
                    isCurrent = index == currentStageIndex,
                    isLast = index == stages.size - 1
                )
            }
        }
    }
}

@Composable
fun TimelineItem(title: String, isCompleted: Boolean, isCurrent: Boolean, isLast: Boolean) {
    Row(modifier = Modifier.height(IntrinsicSize.Min)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .background(
                        color = if (isCompleted || isCurrent) PrimaryBlue else Color.LightGray,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isCompleted) {
                    Text("✓", color = Color.White, fontSize = 12.sp)
                }
            }
            if (!isLast) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .weight(1f)
                        .background(if (isCompleted) PrimaryBlue else Color.LightGray)
                )
            }
        }
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Column(modifier = Modifier.padding(bottom = 24.dp)) {
            Text(
                text = title,
                fontSize = 16.sp,
                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                color = if (isCurrent) PrimaryBlue else if (isCompleted) Color.Black else Color.Gray
            )
            if (isCurrent) {
                Text("Update: Laundry is currently being washed.", fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}
