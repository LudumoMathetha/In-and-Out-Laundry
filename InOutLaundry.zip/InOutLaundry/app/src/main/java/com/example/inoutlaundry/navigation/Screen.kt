package com.example.inoutlaundry.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Onboarding : Screen("onboarding")
    object Login : Screen("login")
    object Register : Screen("register")
    object Home : Screen("home")
    object Services : Screen("services")
    object Booking : Screen("booking")
    object BookingSummary : Screen("booking_summary")
    object Payment : Screen("payment")
    object OrderConfirmation : Screen("order_confirmation")
    object Tracking : Screen("tracking")
    object MyOrders : Screen("my_orders")
    object OrderDetails : Screen("order_details/{orderId}") {
        fun createRoute(orderId: Int) = "order_details/$orderId"
    }
    object Notifications : Screen("notifications")
    object Profile : Screen("profile")
    object Support : Screen("support")
    object About : Screen("about")
}
