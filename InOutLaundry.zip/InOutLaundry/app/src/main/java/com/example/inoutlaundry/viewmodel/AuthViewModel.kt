package com.example.inoutlaundry.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.inoutlaundry.data.model.Customer
import com.example.inoutlaundry.data.repository.LaundryRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * AUTH VIEW MODEL
 * This class handles all the logic related to user authentication (Login/Register).
 * As third-year students, we use ViewModels to separate our business logic from the UI
 * and to survive configuration changes like screen rotations.
 */
class AuthViewModel(private val repository: LaundryRepository) : ViewModel() {

    // Using a StateFlow to manage the authentication state. 
    // The UI will observe this to show loading spinners or error messages.
    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    // Expose the current user from the repository as a Flow.
    // If the repository updates (e.g., after login), the UI updates automatically.
    val currentUser = repository.customer

    /**
     * Handles the login process.
     * We use viewModelScope.launch to run the network call on a background thread
     * using Kotlin Coroutines, so we don't block the UI.
     */
    fun login(email: String, password: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            // We call the repository and wait for the result
            val result = repository.login(mapOf("email" to email, "password" to password))
            
            // Update the state based on whether the API call was successful
            _authState.value = if (result.isSuccess) {
                AuthState.Authenticated(result.getOrNull()!!)
            } else {
                AuthState.Error(result.exceptionOrNull()?.message ?: "Login failed")
            }
        }
    }

    /**
     * Handles registration for new users.
     */
    fun register(firstName: String, lastName: String, email: String, phone: String, password: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            val customer = Customer(0, firstName, lastName, email, phone)
            val result = repository.register(customer)
            
            _authState.value = if (result.isSuccess) {
                AuthState.Authenticated(result.getOrNull()!!)
            } else {
                AuthState.Error(result.exceptionOrNull()?.message ?: "Registration failed")
            }
        }
    }

    /**
     * Logs the user out by clearing their local session in the repository.
     */
    fun logout() {
        viewModelScope.launch {
            repository.logout()
            _authState.value = AuthState.Idle
        }
    }

    /**
     * AUTH STATE
     * A sealed class representing the different states the Auth process can be in.
     * This makes it easy for the UI to handle all possible scenarios using a 'when' expression.
     */
    sealed class AuthState {
        object Idle : AuthState()
        object Loading : AuthState()
        data class Authenticated(val user: Customer) : AuthState()
        data class Error(val message: String) : AuthState()
    }
}

/**
 * AUTH VIEW MODEL FACTORY
 * Since our ViewModel has a constructor dependency (LaundryRepository), 
 * we need this factory to tell Android how to create it.
 */
class AuthViewModelFactory(private val repository: LaundryRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AuthViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AuthViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
