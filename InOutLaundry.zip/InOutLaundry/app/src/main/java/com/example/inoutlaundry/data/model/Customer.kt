package com.example.inoutlaundry.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey val customerID: Int,
    val firstName: String,
    val lastName: String,
    val email: String,
    val phone: String
)
