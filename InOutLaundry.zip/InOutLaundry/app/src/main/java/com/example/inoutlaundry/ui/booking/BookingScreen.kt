package com.example.inoutlaundry.ui.booking

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.inoutlaundry.data.model.Booking
import com.example.inoutlaundry.data.model.Service
import com.example.inoutlaundry.viewmodel.LaundryViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingScreen(
    viewModel: LaundryViewModel,
    service: Service?,
    onNavigateToSummary: () -> Unit,
    onBack: () -> Unit
) {
    var step by remember { mutableIntStateOf(1) }
    
    var quantity by remember { mutableStateOf("1") }
    var pickupDate by remember { mutableStateOf("") }
    var pickupTime by remember { mutableStateOf("") }
    var pickupAddress by remember { mutableStateOf("") }
    var deliveryAddress by remember { mutableStateOf("") }
    var specialInstructions by remember { mutableStateOf("") }

    val totalAmount = (service?.price ?: 0.0) * (quantity.toDoubleOrNull() ?: 1.0)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Book ${service?.serviceName ?: "Service"}") },
                navigationIcon = {
                    IconButton(onClick = { if (step > 1) step-- else onBack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            LinearProgressIndicator(
                progress = { step / 4f },
                modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
            )

            when (step) {
                1 -> QuantityStep(quantity) { quantity = it }
                2 -> PickupStep(pickupDate, pickupTime, pickupAddress) { d, t, a ->
                    pickupDate = d
                    pickupTime = t
                    pickupAddress = a
                }
                3 -> DeliveryStep(deliveryAddress, specialInstructions) { a, i ->
                    deliveryAddress = a
                    specialInstructions = i
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    if (step < 3) {
                        step++
                    } else {
                        val booking = Booking(
                            bookingID = 0,
                            customerID = 0, // Should be set from AuthViewModel
                            serviceID = service?.serviceID ?: 0,
                            pickupDate = pickupDate,
                            pickupTime = pickupTime,
                            pickupAddress = pickupAddress,
                            deliveryAddress = deliveryAddress,
                            quantity = quantity.toIntOrNull() ?: 1,
                            specialInstructions = specialInstructions,
                            status = "Pending",
                            createdDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                            totalAmount = totalAmount
                        )
                        viewModel.updateBookingDraft(booking)
                        onNavigateToSummary()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = isStepValid(step, quantity, pickupDate, pickupTime, pickupAddress, deliveryAddress)
            ) {
                Text(if (step == 3) "View Summary" else "Next")
            }
        }
    }
}

@Composable
fun QuantityStep(quantity: String, onQuantityChange: (String) -> Unit) {
    Column {
        Text("Laundry Quantity", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("How many items or loads?", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        Spacer(modifier = Modifier.height(24.dp))
        OutlinedTextField(
            value = quantity,
            onValueChange = onQuantityChange,
            label = { Text("Quantity") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
    }
}

@Composable
fun PickupStep(date: String, time: String, address: String, onDetailsChange: (String, String, String) -> Unit) {
    Column {
        Text("Pickup Details", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(24.dp))
        OutlinedTextField(
            value = date,
            onValueChange = { onDetailsChange(it, time, address) },
            label = { Text("Pickup Date (YYYY-MM-DD)") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = time,
            onValueChange = { onDetailsChange(date, it, address) },
            label = { Text("Pickup Time (HH:MM)") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = address,
            onValueChange = { onDetailsChange(date, time, it) },
            label = { Text("Pickup Address") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )
    }
}

@Composable
fun DeliveryStep(address: String, instructions: String, onDetailsChange: (String, String) -> Unit) {
    Column {
        Text("Delivery Details", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(24.dp))
        OutlinedTextField(
            value = address,
            onValueChange = { onDetailsChange(it, instructions) },
            label = { Text("Delivery Address") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = instructions,
            onValueChange = { onDetailsChange(address, it) },
            label = { Text("Special Instructions (Optional)") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )
    }
}

fun isStepValid(step: Int, q: String, pd: String, pt: String, pa: String, da: String): Boolean {
    return when (step) {
        1 -> q.isNotEmpty() && q.toIntOrNull() != null
        2 -> pd.isNotEmpty() && pt.isNotEmpty() && pa.isNotEmpty()
        3 -> da.isNotEmpty()
        else -> false
    }
}
