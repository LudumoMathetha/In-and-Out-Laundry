package com.example.inoutlaundry.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.inoutlaundry.data.model.Order
import com.example.inoutlaundry.ui.theme.PrimaryBlue
import com.example.inoutlaundry.viewmodel.AuthViewModel
import com.example.inoutlaundry.viewmodel.LaundryViewModel

@Composable
fun HomeScreen(
    authViewModel: AuthViewModel,
    laundryViewModel: LaundryViewModel,
    onBookClick: () -> Unit,
    onTrackClick: (String) -> Unit,
    onServiceClick: () -> Unit,
    onNotificationsClick: () -> Unit
) {
    val user by authViewModel.currentUser.collectAsState(initial = null)
    val orders by laundryViewModel.orders.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Hello,", fontSize = 16.sp, color = Color.Gray)
                    Text(
                        text = user?.firstName ?: "Customer",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                IconButton(onClick = onNotificationsClick) {
                    Icon(Icons.Default.Notifications, contentDescription = "Notifications")
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        item {
            ActiveOrderCard(onTrackClick)
            Spacer(modifier = Modifier.height(24.dp))
        }

        item {
            Button(
                onClick = onBookClick,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Book Laundry Service", modifier = Modifier.padding(vertical = 8.dp))
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        item {
            Text("Quick Actions", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                QuickActionItem("Services", "🧺", onServiceClick)
                QuickActionItem("Track", "📍", { /* Navigate to track */ })
                QuickActionItem("Orders", "📋", { /* Navigate to orders */ })
                QuickActionItem("Payment", "💳", { /* Navigate to payment info */ })
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        item {
            Text("Recent Orders", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))
        }

        items(orders.take(3)) { order ->
            OrderListItem(order)
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
fun ActiveOrderCard(onTrackClick: (String) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PrimaryBlue)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("Active Order", color = Color.White.copy(alpha = 0.8f))
            Text("Order #TRK92837", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(8.dp).background(Color.Green, CircleShape))
                Spacer(modifier = Modifier.width(8.dp))
                Text("In Processing", color = Color.White)
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = { onTrackClick("TRK92837") },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = PrimaryBlue)
            ) {
                Text("Track Order")
            }
        }
    }
}

@Composable
fun QuickActionItem(label: String, icon: String, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Text(icon, fontSize = 24.sp)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(label, fontSize = 12.sp)
    }
}

@Composable
fun OrderListItem(order: Order) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(PrimaryBlue.copy(alpha = 0.1f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("👕")
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(text = "Order #${order.trackingNumber}", fontWeight = FontWeight.Bold)
                Text(text = order.orderStatus, color = Color.Gray, fontSize = 14.sp)
            }
            Spacer(modifier = Modifier.weight(1f))
            Text(text = "R250.00", fontWeight = FontWeight.Bold, color = PrimaryBlue)
        }
    }
}
