package com.example.inoutlaundry.data.remote

import com.example.inoutlaundry.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface LaundryApiService {
    @POST("api/auth/login")
    suspend fun login(@Body credentials: Map<String, String>): Response<Customer>

    @POST("api/auth/register")
    suspend fun register(@Body customer: Customer): Response<Customer>

    @GET("api/services")
    suspend fun getServices(): Response<List<Service>>

    @POST("api/bookings")
    suspend fun createBooking(@Body booking: Booking): Response<Booking>

    @GET("api/bookings/customer/{customerId}")
    suspend fun getBookings(@Path("customerId") customerId: Int): Response<List<Booking>>

    @GET("api/orders/customer/{customerId}")
    suspend fun getOrders(@Path("customerId") customerId: Int): Response<List<Order>>

    @GET("api/orders/tracking/{trackingNumber}")
    suspend fun trackOrder(@Path("trackingNumber") trackingNumber: String): Response<Order>

    @POST("api/payments")
    suspend fun processPayment(@Body payment: Payment): Response<Payment>

    @GET("api/notifications/{customerId}")
    suspend fun getNotifications(@Path("customerId") customerId: Int): Response<List<Notification>>

    @PUT("api/profile/{customerId}")
    suspend fun updateProfile(@Path("customerId") customerId: Int, @Body customer: Customer): Response<Customer>
}
