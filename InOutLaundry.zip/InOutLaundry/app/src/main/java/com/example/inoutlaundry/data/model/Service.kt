package com.example.inoutlaundry.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "services")
data class Service(
    @PrimaryKey val serviceID: Int,
    val serviceName: String,
    val description: String,
    val price: Double,
    val iconResId: Int? = null
)
