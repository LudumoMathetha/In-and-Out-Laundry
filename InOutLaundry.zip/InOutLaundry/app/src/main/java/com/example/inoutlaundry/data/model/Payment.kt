package com.example.inoutlaundry.data.model

data class Payment(
    val paymentID: Int,
    val bookingID: Int,
    val amount: Double,
    val paymentMethod: String,
    val paymentStatus: String,
    val paymentDate: String
)
