package com.example.inoutlaundry.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.inoutlaundry.data.model.*

@Database(
    entities = [Customer::class, Service::class, Booking::class, Order::class, Notification::class],
    version = 1,
    exportSchema = false
)
abstract class LaundryDatabase : RoomDatabase() {
    abstract fun laundryDao(): LaundryDao

    companion object {
        @Volatile
        private var INSTANCE: LaundryDatabase? = null

        fun getDatabase(context: Context): LaundryDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    LaundryDatabase::class.java,
                    "laundry_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
