package com.example.inoutlaundry.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notifications")
data class Notification(
    @PrimaryKey(autoGenerate = true) val notificationID: Int = 0,
    val customerID: Int,
    val title: String,
    val message: String,
    val dateCreated: String,
    val isRead: Boolean = false
)
