package com.example.inoutlaundry.ui.theme

import androidx.compose.ui.graphics.Color

val DarkNavyBlue = Color(0xFF001F3F)
val PrimaryBlue = Color(0xFF0074D9)
val LightBlue = Color(0xFF7FDBFF)
val Teal = Color(0xFF39CCCC)
val White = Color(0xFFFFFFFF)
val LightGrey = Color(0xFFF8F9FA)
val DarkGrey = Color(0xFF343A40)

val Primary = PrimaryBlue
val OnPrimary = White
val Secondary = Teal
val OnSecondary = White
val Tertiary = LightBlue
val Background = LightGrey
val OnBackground = DarkNavyBlue
val Surface = White
val OnSurface = DarkNavyBlue
