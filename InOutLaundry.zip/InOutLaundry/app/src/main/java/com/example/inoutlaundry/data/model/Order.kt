package com.example.inoutlaundry.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey val orderID: Int,
    val bookingID: Int,
    val trackingNumber: String,
    val orderStatus: String,
    val updatedDate: String
)
