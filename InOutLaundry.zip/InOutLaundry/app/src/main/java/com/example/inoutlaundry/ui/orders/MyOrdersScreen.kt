package com.example.inoutlaundry.ui.orders

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.inoutlaundry.ui.home.OrderListItem
import com.example.inoutlaundry.viewmodel.LaundryViewModel

@Composable
fun MyOrdersScreen(
    viewModel: LaundryViewModel,
    onOrderClick: (Int) -> Unit
) {
    val orders by viewModel.orders.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("My Orders", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        TabRow(selectedTabIndex = selectedTab) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) {
                Text("Current", modifier = Modifier.padding(16.dp))
            }
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) {
                Text("Previous", modifier = Modifier.padding(16.dp))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            val filteredOrders = if (selectedTab == 0) {
                orders.filter { it.orderStatus != "Delivered" }
            } else {
                orders.filter { it.orderStatus == "Delivered" }
            }

            if (filteredOrders.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().height(200.dp), contentAlignment = androidx.compose.ui.Alignment.Center) {
                        Text("No orders found", color = androidx.compose.ui.graphics.Color.Gray)
                    }
                }
            } else {
                items(filteredOrders) { order ->
                    OrderListItem(order = order)
                }
            }
        }
    }
}
