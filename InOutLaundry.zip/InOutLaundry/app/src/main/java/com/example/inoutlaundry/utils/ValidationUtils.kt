package com.example.inoutlaundry.utils

import android.util.Patterns

object ValidationUtils {
    fun isValidEmail(email: String): Boolean {
        return email.isNotEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    fun isValidPassword(password: String): Boolean {
        return password.length >= 6
    }

    fun passwordsMatch(password: String, confirm: String): Boolean {
        return password == confirm
    }

    fun isValidPhone(phone: String): Boolean {
        return phone.length >= 10
    }

    fun calculateTotalPrice(servicePrice: Double, quantity: Int): Double {
        return servicePrice * quantity
    }

    fun isValidTrackingNumber(trackingNumber: String): Boolean {
        return trackingNumber.startsWith("TRK") && trackingNumber.length == 8
    }

    fun getStatusColor(status: String): String {
        return when (status) {
            "Delivered" -> "#4CAF50"
            "Cancelled" -> "#F44336"
            "Pending" -> "#FF9800"
            else -> "#2196F3"
        }
    }
}
