package com.example.inoutlaundry.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.inoutlaundry.LaundryApplication
import com.example.inoutlaundry.ui.about.AboutScreen
import com.example.inoutlaundry.ui.auth.LoginScreen
import com.example.inoutlaundry.ui.auth.RegisterScreen
import com.example.inoutlaundry.ui.booking.BookingScreen
import com.example.inoutlaundry.ui.booking.BookingSummaryScreen
import com.example.inoutlaundry.ui.home.HomeScreen
import com.example.inoutlaundry.ui.notifications.NotificationsScreen
import com.example.inoutlaundry.ui.onboarding.OnboardingScreen
import com.example.inoutlaundry.ui.order.OrderConfirmationScreen
import com.example.inoutlaundry.ui.order.OrderDetailsScreen
import com.example.inoutlaundry.ui.orders.MyOrdersScreen
import com.example.inoutlaundry.ui.payment.PaymentScreen
import com.example.inoutlaundry.ui.profile.ProfileScreen
import com.example.inoutlaundry.ui.services.ServicesScreen
import com.example.inoutlaundry.ui.splash.SplashScreen
import com.example.inoutlaundry.ui.support.SupportScreen
import com.example.inoutlaundry.ui.tracking.TrackingScreen
import com.example.inoutlaundry.viewmodel.AuthViewModel
import com.example.inoutlaundry.viewmodel.AuthViewModelFactory
import com.example.inoutlaundry.viewmodel.LaundryViewModel
import com.example.inoutlaundry.viewmodel.LaundryViewModelFactory

@Composable
fun AppNavigation(
    navController: NavHostController,
    application: LaundryApplication
) {
    val repository = application.repository
    val authViewModel: AuthViewModel = viewModel(factory = AuthViewModelFactory(repository))
    val laundryViewModel: LaundryViewModel = viewModel(factory = LaundryViewModelFactory(repository))
    
    val currentUser by authViewModel.currentUser.collectAsState(initial = null)

    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route
    ) {
        composable(Screen.Splash.route) {
            SplashScreen(onNavigate = {
                if (currentUser != null) {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                } else {
                    navController.navigate(Screen.Onboarding.route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                }
            })
        }

        composable(Screen.Onboarding.route) {
            OnboardingScreen(onFinish = {
                navController.navigate(Screen.Login.route) {
                    popUpTo(Screen.Onboarding.route) { inclusive = true }
                }
            })
        }

        composable(Screen.Login.route) {
            LoginScreen(
                viewModel = authViewModel,
                onLoginSuccess = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                },
                onRegisterClick = {
                    navController.navigate(Screen.Register.route)
                }
            )
        }

        composable(Screen.Register.route) {
            RegisterScreen(
                viewModel = authViewModel,
                onRegisterSuccess = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Register.route) { inclusive = true }
                    }
                },
                onLoginClick = {
                    navController.navigate(Screen.Login.route)
                }
            )
        }

        composable(Screen.Home.route) {
            HomeScreen(
                authViewModel = authViewModel,
                laundryViewModel = laundryViewModel,
                onBookClick = { navController.navigate(Screen.Services.route) },
                onTrackClick = { trackingNum -> 
                    navController.navigate(Screen.Tracking.route + "?num=$trackingNum") 
                },
                onServiceClick = { navController.navigate(Screen.Services.route) },
                onNotificationsClick = { navController.navigate(Screen.Notifications.route) }
            )
        }

        composable(Screen.Services.route) {
            ServicesScreen(
                viewModel = laundryViewModel,
                onServiceSelect = { service ->
                    navController.navigate(Screen.Booking.route)
                }
            )
        }

        composable(Screen.Booking.route) {
            val services by laundryViewModel.services.collectAsState()
            BookingScreen(
                viewModel = laundryViewModel,
                service = services.firstOrNull(),
                onNavigateToSummary = { navController.navigate(Screen.BookingSummary.route) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Screen.BookingSummary.route) {
            BookingSummaryScreen(
                viewModel = laundryViewModel,
                onConfirm = { navController.navigate(Screen.Payment.route) },
                onEdit = { navController.popBackStack() },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Payment.route) {
            PaymentScreen(
                viewModel = laundryViewModel,
                onPaymentSuccess = { trackingNumber ->
                    navController.navigate(Screen.OrderConfirmation.route + "/$trackingNumber") {
                        popUpTo(Screen.Booking.route) { inclusive = true }
                    }
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.OrderConfirmation.route + "/{trackingNumber}",
            arguments = listOf(navArgument("trackingNumber") { type = NavType.StringType })
        ) { backStackEntry ->
            val trackingNumber = backStackEntry.arguments?.getString("trackingNumber") ?: ""
            OrderConfirmationScreen(
                trackingNumber = trackingNumber,
                onTrackClick = { navController.navigate(Screen.Tracking.route + "?num=$trackingNumber") },
                onHomeClick = { 
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Home.route) { inclusive = true }
                    }
                }
            )
        }

        composable(
            route = Screen.Tracking.route + "?num={num}",
            arguments = listOf(navArgument("num") { defaultValue = ""; type = NavType.StringType })
        ) { backStackEntry ->
            val num = backStackEntry.arguments?.getString("num") ?: ""
            TrackingScreen(viewModel = laundryViewModel, initialTrackingNumber = num)
        }

        composable(Screen.MyOrders.route) {
            MyOrdersScreen(
                viewModel = laundryViewModel,
                onOrderClick = { orderId ->
                    navController.navigate(Screen.OrderDetails.createRoute(orderId))
                }
            )
        }

        composable(
            route = Screen.OrderDetails.route,
            arguments = listOf(navArgument("orderId") { type = NavType.IntType })
        ) { backStackEntry ->
            val orderId = backStackEntry.arguments?.getInt("orderId") ?: 0
            OrderDetailsScreen(orderId = orderId, onBack = { navController.popBackStack() })
        }

        composable(Screen.Notifications.route) {
            NotificationsScreen(viewModel = laundryViewModel, onBack = { navController.popBackStack() })
        }

        composable(Screen.Profile.route) {
            ProfileScreen(
                authViewModel = authViewModel,
                onLogout = {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(0) { inclusive = true }
                    }
                },
                onNavigateToSupport = { navController.navigate(Screen.Support.route) },
                onNavigateToAbout = { navController.navigate(Screen.About.route) }
            )
        }

        composable(Screen.Support.route) {
            SupportScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.About.route) {
            AboutScreen(onBack = { navController.popBackStack() })
        }
    }
}
