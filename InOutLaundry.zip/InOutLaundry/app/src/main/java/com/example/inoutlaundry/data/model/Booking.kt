package com.example.inoutlaundry.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookings")
data class Booking(
    @PrimaryKey val bookingID: Int,
    val customerID: Int,
    val serviceID: Int,
    val pickupDate: String,
    val pickupTime: String,
    val pickupAddress: String,
    val deliveryAddress: String,
    val quantity: Int,
    val specialInstructions: String,
    val status: String,
    val createdDate: String,
    val totalAmount: Double
)
