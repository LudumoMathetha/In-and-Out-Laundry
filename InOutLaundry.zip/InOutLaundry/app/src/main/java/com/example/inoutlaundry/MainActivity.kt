package com.example.inoutlaundry

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.LocalLaundryService
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.inoutlaundry.navigation.AppNavigation
import com.example.inoutlaundry.navigation.Screen
import com.example.inoutlaundry.ui.theme.InOutLaundryTheme

/**
 * MAIN ACTIVITY
 * This is the entry point for the In & Out Laundry mobile application.
 * As third-year software development students, we implemented a Single Activity Architecture
 * using Jetpack Compose to keep the UI modern and responsive for our WIL project.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Enabling edge-to-edge for a professional, immersive feel
        enableEdgeToEdge()
        
        setContent {
            InOutLaundryTheme {
                // Initialize the NavController which handles all screen transitions in the app
                val navController = rememberNavController()
                
                // We observe the backstack to determine which screen is currently active
                // This is crucial for correctly highlighting the bottom navigation items.
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination

                // NAVIGATION LOGIC:
                // We only want the bottom navigation bar to appear on the main functional screens.
                // We hide it on Splash, Login, and Onboarding to follow UX best practices and keep users focused.
                val bottomBarScreens = listOf(
                    Screen.Home.route,
                    Screen.Services.route,
                    Screen.MyOrders.route,
                    Screen.Profile.route
                )

                val currentRoute = currentDestination?.route ?: ""
                
                // Using startsWith for Tracking because it contains query parameters for tracking numbers
                val showBottomBar = bottomBarScreens.any { it == currentRoute } || 
                                   currentRoute.startsWith(Screen.Tracking.route)

                // Scaffold provides a standard Material Design layout structure (TopBar, BottomBar, etc.)
                Scaffold(
                    bottomBar = {
                        if (showBottomBar) {
                            NavigationBar {
                                // List of tabs for the bottom navigation menu
                                val items = listOf(
                                    NavigationItem("Home", Screen.Home.route, Icons.Default.Home),
                                    NavigationItem("Services", Screen.Services.route, Icons.Default.LocalLaundryService),
                                    NavigationItem("Orders", Screen.MyOrders.route, Icons.Default.ListAlt),
                                    NavigationItem("Tracking", Screen.Tracking.route + "?num=", Icons.Default.LocationOn),
                                    NavigationItem("Profile", Screen.Profile.route, Icons.Default.Person)
                                )

                                items.forEach { item ->
                                    // Highlight the selected item based on the navigation hierarchy
                                    val isSelected = currentDestination?.hierarchy?.any { 
                                        val route = it.route ?: ""
                                        // Compare base routes without query parameters
                                        route.split("?")[0] == item.route.split("?")[0]
                                    } == true
                                    
                                    NavigationBarItem(
                                        icon = { Icon(item.icon, contentDescription = item.label) },
                                        label = { Text(item.label) },
                                        selected = isSelected,
                                        onClick = {
                                            // Follow standard navigation patterns for Bottom Navigation:
                                            // - Pop up to the start destination to avoid building a huge backstack
                                            // - restoreState so the user doesn't lose progress when switching between tabs
                                            navController.navigate(item.route) {
                                                popUpTo(navController.graph.findStartDestination().id) {
                                                    saveState = true
                                                }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    // Main container for the screen content, applying padding from the Scaffold
                    Surface(modifier = Modifier.padding(innerPadding)) {
                        AppNavigation(
                            navController = navController,
                            application = application as LaundryApplication
                        )
                    }
                }
            }
        }
    }
}

/**
 * Data class to represent a menu item in the bottom navigation bar.
 */
data class NavigationItem(val label: String, val route: String, val icon: ImageVector)
