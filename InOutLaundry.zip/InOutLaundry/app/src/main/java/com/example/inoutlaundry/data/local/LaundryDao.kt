package com.example.inoutlaundry.data.local

import androidx.room.*
import com.example.inoutlaundry.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface LaundryDao {
    @Query("SELECT * FROM customers LIMIT 1")
    fun getCustomer(): Flow<Customer?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: Customer)

    @Query("DELETE FROM customers")
    suspend fun clearCustomer()

    @Query("SELECT * FROM services")
    fun getServices(): Flow<List<Service>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServices(services: List<Service>)

    @Query("SELECT * FROM bookings ORDER BY createdDate DESC")
    fun getBookings(): Flow<List<Booking>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookings(bookings: List<Booking>)

    @Query("SELECT * FROM orders ORDER BY updatedDate DESC")
    fun getOrders(): Flow<List<Order>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrders(orders: List<Order>)

    @Query("SELECT * FROM notifications ORDER BY dateCreated DESC")
    fun getNotifications(): Flow<List<Notification>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<Notification>)

    @Update
    suspend fun updateNotification(notification: Notification)
}
