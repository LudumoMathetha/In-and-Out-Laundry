package com.example.inoutlaundry.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.inoutlaundry.ui.theme.PrimaryBlue
import com.example.inoutlaundry.viewmodel.AuthViewModel

@Composable
fun ProfileScreen(
    authViewModel: AuthViewModel,
    onLogout: () -> Unit,
    onNavigateToSupport: () -> Unit,
    onNavigateToAbout: () -> Unit
) {
    val user by authViewModel.currentUser.collectAsState(initial = null)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        
        Surface(
            modifier = Modifier.size(100.dp),
            shape = CircleShape,
            color = PrimaryBlue.copy(alpha = 0.1f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = user?.firstName?.firstOrNull()?.toString() ?: "C",
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryBlue
                )
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "${user?.firstName ?: "Customer"} ${user?.lastName ?: ""}",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )
        Text(text = user?.email ?: "", color = Color.Gray)
        
        Spacer(modifier = Modifier.height(32.dp))

        ProfileMenuItem("Personal Information", Icons.Default.Person) { }
        ProfileMenuItem("Saved Addresses", Icons.Default.LocationOn) { }
        ProfileMenuItem("Payment Methods", Icons.Default.Payment) { }
        ProfileMenuItem("Notification Settings", Icons.Default.Notifications) { }
        ProfileMenuItem("Change Password", Icons.Default.Lock) { }
        ProfileMenuItem("Help & Support", Icons.Default.Help, onClick = onNavigateToSupport)
        ProfileMenuItem("About In & Out Laundry", Icons.Default.Info, onClick = onNavigateToAbout)
        
        Spacer(modifier = Modifier.height(24.dp))
        
        TextButton(
            onClick = {
                authViewModel.logout()
                onLogout()
            },
            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
        ) {
            Icon(Icons.Default.ExitToApp, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Logout", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun ProfileMenuItem(label: String, icon: ImageVector, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        onClick = onClick,
        shape = MaterialTheme.shapes.medium,
        tonalElevation = 1.dp
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = PrimaryBlue)
            Spacer(modifier = Modifier.width(16.dp))
            Text(text = label, modifier = Modifier.weight(1f), fontSize = 16.sp)
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
        }
    }
}
