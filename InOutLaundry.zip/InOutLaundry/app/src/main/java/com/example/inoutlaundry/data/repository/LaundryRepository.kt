package com.example.inoutlaundry.data.repository

import com.example.inoutlaundry.data.local.LaundryDao
import com.example.inoutlaundry.data.model.*
import com.example.inoutlaundry.data.remote.LaundryApiService
import kotlinx.coroutines.flow.Flow

/**
 * Repository class that acts as the single source of truth for the app's data.
 * In our third-year project, we use this to manage data from both the Room local database
 * and the Retrofit REST API. This follows the Repository Pattern we learned in class.
 */
class LaundryRepository(
    private val laundryDao: LaundryDao,
    private val apiService: LaundryApiService
) {
    // Flows that the UI can observe to get real-time updates from the local database
    val customer: Flow<Customer?> = laundryDao.getCustomer()
    val services: Flow<List<Service>> = laundryDao.getServices()
    val bookings: Flow<List<Booking>> = laundryDao.getBookings()
    val orders: Flow<List<Order>> = laundryDao.getOrders()
    val notifications: Flow<List<Notification>> = laundryDao.getNotifications()

    /**
     * Attempts to log in the user via the API.
     * If successful, we save the customer data locally in Room for persistence.
     */
    suspend fun login(credentials: Map<String, String>): Result<Customer> {
        return try {
            val response = apiService.login(credentials)
            if (response.isSuccessful && response.body() != null) {
                val user = response.body()!!
                // Cache the user locally so they don't have to log in every time the app opens
                laundryDao.insertCustomer(user)
                Result.success(user)
            } else {
                Result.failure(Exception("Login failed: ${response.message()}"))
            }
        } catch (e: Exception) {
            // Handle network errors (e.g., no internet connection)
            Result.failure(e)
        }
    }

    /**
     * Registers a new customer using the remote API.
     */
    suspend fun register(customer: Customer): Result<Customer> {
        return try {
            val response = apiService.register(customer)
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                Result.failure(Exception("Registration failed: ${response.message()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Fetches the list of laundry services from the API and caches them in Room.
     * This allows the app to work offline if services have been loaded before.
     */
    suspend fun fetchServices() {
        try {
            val response = apiService.getServices()
            if (response.isSuccessful && response.body() != null) {
                laundryDao.insertServices(response.body()!!)
            }
        } catch (e: Exception) {
            // We just catch the error here; the UI will still show cached data from the Flow
        }
    }

    /**
     * Sends a new booking to the server and updates the local database.
     */
    suspend fun createBooking(booking: Booking): Result<Booking> {
        return try {
            val response = apiService.createBooking(booking)
            if (response.isSuccessful && response.body() != null) {
                val newBooking = response.body()!!
                laundryDao.insertBookings(listOf(newBooking))
                Result.success(newBooking)
            } else {
                Result.failure(Exception("Booking failed"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Retrieves order status based on a tracking number.
     */
    suspend fun trackOrder(trackingNumber: String): Result<Order> {
        return try {
            val response = apiService.trackOrder(trackingNumber)
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                Result.failure(Exception("Tracking failed"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Clears local user data when logging out.
     */
    suspend fun logout() {
        laundryDao.clearCustomer()
    }
}
