package com.example.inoutlaundry

import android.app.Application
import com.example.inoutlaundry.data.local.LaundryDatabase
import com.example.inoutlaundry.data.remote.LaundryApiService
import com.example.inoutlaundry.data.repository.LaundryRepository
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * Custom Application class for In & Out Laundry.
 * As per third-year best practices, we use this class to initialize our manual Dependency Injection.
 * This ensures that our database and repository instances live for the entire lifetime of the app.
 */
class LaundryApplication : Application() {
    
    // Initialize the Room database using a lazy delegate so it's only created when first needed.
    val database by lazy { LaundryDatabase.getDatabase(this) }
    
    // The Base URL for our ASP.NET Core Web API. 
    // This is easily configurable for different environments (Localhost, Azure, etc.)
    private val BASE_URL = "https://api.inoutlaundry.example.com/" 

    // Retrofit instance setup with Gson converter to handle JSON mapping automatically.
    private val retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    // Create the API service interface implementation.
    private val apiService by lazy {
        retrofit.create(LaundryApiService::class.java)
    }

    // The central repository that our ViewModels will interact with.
    // We pass in the DAO and the API service to satisfy its dependencies.
    val repository by lazy { 
        LaundryRepository(database.laundryDao(), apiService) 
    }
}
