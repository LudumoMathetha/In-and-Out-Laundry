package com.example.inoutlaundry.ui.order

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.inoutlaundry.ui.booking.SummaryItem
import com.example.inoutlaundry.ui.theme.PrimaryBlue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderDetailsScreen(
    orderId: Int,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Order Details") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("Order #$orderId", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = PrimaryBlue)
            Spacer(modifier = Modifier.height(16.dp))
            
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SummaryItem("Status", "Processing")
                    SummaryItem("Tracking Number", "TRK92837")
                    SummaryItem("Service", "Wash & Fold")
                    SummaryItem("Quantity", "2 loads")
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            Text("Pickup Information", fontWeight = FontWeight.Bold)
            Text("Date: 2023-10-25")
            Text("Address: 123 Main St, Cape Town")
            
            Spacer(modifier = Modifier.height(16.dp))
            Text("Delivery Information", fontWeight = FontWeight.Bold)
            Text("Address: 123 Main St, Cape Town")
            
            Spacer(modifier = Modifier.height(24.dp))
            Text("Payment", fontWeight = FontWeight.Bold)
            Text("Amount: R250.00")
            Text("Status: Paid")
            Text("Method: Card")
        }
    }
}
