package com.example.inoutlaundry.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.inoutlaundry.data.model.*
import com.example.inoutlaundry.data.repository.LaundryRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class LaundryViewModel(private val repository: LaundryRepository) : ViewModel() {

    val services: StateFlow<List<Service>> = repository.services
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookings: StateFlow<List<Booking>> = repository.bookings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<Order>> = repository.orders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<Notification>> = repository.notifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentBooking = MutableStateFlow<Booking?>(null)
    val currentBooking: StateFlow<Booking?> = _currentBooking.asStateFlow()

    init {
        viewModelScope.launch {
            repository.fetchServices()
        }
    }

    fun updateBookingDraft(booking: Booking) {
        _currentBooking.value = booking
    }

    fun confirmBooking(booking: Booking) {
        viewModelScope.launch {
            val result = repository.createBooking(booking)
            // Handle result (e.g., update state for UI feedback)
        }
    }

    fun trackOrder(trackingNumber: String): Flow<Result<Order>> = flow {
        emit(repository.trackOrder(trackingNumber))
    }
}

class LaundryViewModelFactory(private val repository: LaundryRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(LaundryViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return LaundryViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
