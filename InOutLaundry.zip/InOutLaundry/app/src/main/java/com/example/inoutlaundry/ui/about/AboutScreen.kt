package com.example.inoutlaundry.ui.about

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("About") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(text = "In & Out Laundry", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(text = "Clean Clothes, Happy Life.", fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text(text = "Company Information", fontWeight = FontWeight.Bold)
            Text(text = "In & Out Laundry provides premium laundry services with a focus on convenience and quality. We take the hassle out of your laundry day.")
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(text = "Operating Hours", fontWeight = FontWeight.Bold)
            Text(text = "Monday - Friday: 08:00 - 18:00\nSaturday: 09:00 - 15:00\nSunday: Closed")
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(text = "Service Areas", fontWeight = FontWeight.Bold)
            Text(text = "Cape Town, Johannesburg, Pretoria, Durban.")
            
            Spacer(modifier = Modifier.height(24.dp))
            
            TextButton(onClick = { /* Open URL */ }) { Text("Terms and Conditions") }
            TextButton(onClick = { /* Open URL */ }) { Text("Privacy Policy") }
            
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = "Version 1.0.0", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), fontSize = 12.sp)
        }
    }
}
