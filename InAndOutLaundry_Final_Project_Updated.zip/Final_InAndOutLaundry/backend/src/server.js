require('dotenv').config();
const express = require('express');
const cors = require('cors');
const sql = require('mssql');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());
app.use(express.json());

const port = process.env.PORT || 3000;
const poolConfig = {
  server: process.env.DB_SERVER || 'localhost',
  port: Number(process.env.DB_PORT || 1433),
  database: process.env.DB_NAME || 'InAndOutLaundry',
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  options: { encrypt: process.env.DB_ENCRYPT === 'true', trustServerCertificate: process.env.DB_TRUST_CERT !== 'false' },
  pool: { max: 10, min: 0, idleTimeoutMillis: 30000 }
};
let poolPromise;
function db(){ if(!poolPromise) poolPromise = sql.connect(poolConfig); return poolPromise; }
function tokenFor(user){ return jwt.sign({id:user.id,email:user.email,role:user.role}, process.env.JWT_SECRET || 'dev-secret', {expiresIn:'8h'}); }
function auth(req,res,next){ try { const h=req.headers.authorization||''; if(!h.startsWith('Bearer ')) return res.status(401).json({message:'Authentication required'}); req.user=jwt.verify(h.slice(7),process.env.JWT_SECRET||'dev-secret'); next(); } catch(e){ res.status(401).json({message:'Invalid or expired token'}); } }
function admin(req,res,next){ if(req.user?.role!=='Admin') return res.status(403).json({message:'Admin access required'}); next(); }
function makeOrderId(){ return `IOL-${Date.now().toString(36).toUpperCase()}-${Math.floor(100+Math.random()*900)}`; }

app.get('/api/health', async (req,res)=>{ try { await db(); res.json({status:'ok',database:'connected',service:'In & Out Laundry API'}); } catch(e){ res.status(503).json({status:'error',database:'unavailable',message:'Database connection failed'}); } });

app.get('/api/services', async (req,res)=>{ try { const r=await (await db()).request().query('SELECT ServiceID id, ServiceName name, Unit unit, Price price FROM Services WHERE IsActive=1 ORDER BY ServiceID'); res.json(r.recordset); } catch(e){ res.status(500).json({message:'Unable to load services'}); } });

app.post('/api/auth/register', async (req,res)=>{ const {name,email,phone,password}=req.body; if(!name||!email||!phone||!password) return res.status(400).json({message:'Name, email, phone and password are required'}); try { const p=await db(); const existing=await p.request().input('email',sql.VarChar(150),email.trim().toLowerCase()).query('SELECT CustomerID FROM Customers WHERE Email=@email'); if(existing.recordset.length) return res.status(409).json({message:'Email already registered'}); const hash=await bcrypt.hash(password,12); const r=await p.request().input('name',sql.VarChar(120),name.trim()).input('email',sql.VarChar(150),email.trim().toLowerCase()).input('phone',sql.VarChar(30),phone.trim()).input('hash',sql.VarChar(255),hash).query('INSERT INTO Customers(FullName,Email,Phone,PasswordHash) OUTPUT INSERTED.CustomerID id,INSERTED.FullName name,INSERTED.Email email,INSERTED.Phone phone VALUES(@name,@email,@phone,@hash)'); const user={...r.recordset[0],role:'Customer'}; res.status(201).json({user,token:tokenFor(user)}); } catch(e){ res.status(500).json({message:'Registration failed'}); } });

app.post('/api/auth/login', async (req,res)=>{ const {email,password}=req.body; try { const p=await db(); let r=await p.request().input('email',sql.VarChar(150),String(email||'').trim().toLowerCase()).query('SELECT CustomerID id,FullName name,Email email,Phone phone,PasswordHash passwordHash FROM Customers WHERE Email=@email'); if(r.recordset.length){ const u=r.recordset[0]; if(await bcrypt.compare(password||'',u.passwordHash)){ delete u.passwordHash; u.role='Customer'; return res.json({user:u,token:tokenFor(u)}); } } r=await p.request().input('email',sql.VarChar(150),String(email||'').trim().toLowerCase()).query('SELECT AdminID id,FullName name,Email email,PasswordHash passwordHash FROM Admins WHERE Email=@email AND IsActive=1'); if(r.recordset.length){ const u=r.recordset[0]; if(await bcrypt.compare(password||'',u.passwordHash)){ delete u.passwordHash; u.role='Admin'; return res.json({user:u,token:tokenFor(u)}); } } res.status(401).json({message:'Invalid email or password'}); } catch(e){ res.status(500).json({message:'Login failed'}); } });

app.get('/api/me',auth,async(req,res)=>{ try{const p=await db(); if(req.user.role==='Admin'){const r=await p.request().input('id',sql.Int,req.user.id).query('SELECT AdminID id,FullName name,Email email FROM Admins WHERE AdminID=@id'); return res.json({...r.recordset[0],role:'Admin'});} const r=await p.request().input('id',sql.Int,req.user.id).query('SELECT CustomerID id,FullName name,Email email,Phone phone FROM Customers WHERE CustomerID=@id'); res.json({...r.recordset[0],role:'Customer'});}catch(e){res.status(500).json({message:'Unable to load profile'});} });

app.post('/api/orders',auth,async(req,res)=>{ if(req.user.role!=='Customer') return res.status(403).json({message:'Customer account required'}); const {serviceId,quantity,date,address,notes}=req.body; if(!serviceId||!quantity||!date||!address) return res.status(400).json({message:'Service, quantity, collection date and address are required'}); try{const p=await db(); const svc=await p.request().input('id',sql.Int,serviceId).query('SELECT Price FROM Services WHERE ServiceID=@id AND IsActive=1'); if(!svc.recordset.length)return res.status(400).json({message:'Invalid service'}); const orderId=makeOrderId(); const amount=Number(svc.recordset[0].Price)*Number(quantity); await p.request().input('oid',sql.VarChar(30),orderId).input('cid',sql.Int,req.user.id).input('sid',sql.Int,serviceId).input('qty',sql.Decimal(10,2),quantity).input('date',sql.Date,date).input('address',sql.VarChar(255),address).input('notes',sql.VarChar(500),notes||'').input('amount',sql.Decimal(10,2),amount).query(`INSERT INTO Orders(OrderID,CustomerID,ServiceID,Quantity,CollectionDate,Address,Notes,Status) VALUES(@oid,@cid,@sid,@qty,@date,@address,@notes,'Pending'); INSERT INTO Payments(OrderID,Amount,PaymentStatus) VALUES(@oid,@amount,'Pending');`); res.status(201).json({id:orderId,status:'Pending',amount});}catch(e){res.status(500).json({message:'Booking could not be created'});} });

app.get('/api/orders',auth,async(req,res)=>{try{const p=await db();let q='SELECT o.OrderID id,c.FullName name,c.Email email,s.ServiceName service,o.Quantity quantity,o.CollectionDate date,o.Address address,o.Notes notes,o.Status status,o.CreatedAt createdAt,ISNULL(pay.Amount,0) amount,ISNULL(pay.PaymentStatus,\'Pending\') paymentStatus FROM Orders o JOIN Customers c ON c.CustomerID=o.CustomerID JOIN Services s ON s.ServiceID=o.ServiceID LEFT JOIN Payments pay ON pay.OrderID=o.OrderID'; if(req.user.role==='Customer') q+=' WHERE o.CustomerID=@cid'; q+=' ORDER BY o.CreatedAt DESC'; const reqq=p.request(); if(req.user.role==='Customer') reqq.input('cid',sql.Int,req.user.id); const r=await reqq.query(q); res.json(r.recordset);}catch(e){res.status(500).json({message:'Unable to load orders'});} });

app.get('/api/orders/:id',auth,async(req,res)=>{try{const p=await db();const r=await p.request().input('oid',sql.VarChar(30),req.params.id).query('SELECT o.OrderID id,c.FullName name,c.Email email,s.ServiceName service,o.Quantity quantity,o.CollectionDate date,o.Address address,o.Notes notes,o.Status status,o.CreatedAt createdAt,ISNULL(pay.Amount,0) amount,ISNULL(pay.PaymentStatus,\'Pending\') paymentStatus FROM Orders o JOIN Customers c ON c.CustomerID=o.CustomerID JOIN Services s ON s.ServiceID=o.ServiceID LEFT JOIN Payments pay ON pay.OrderID=o.OrderID WHERE o.OrderID=@oid');if(!r.recordset.length)return res.status(404).json({message:'Order not found'});const o=r.recordset[0];if(req.user.role==='Customer' && o.email!==req.user.email)return res.status(403).json({message:'Not authorised'});res.json(o);}catch(e){res.status(500).json({message:'Unable to find order'});} });

app.patch('/api/orders/:id/status',auth,admin,async(req,res)=>{const allowed=['Pending','Collected','Cleaning','Ready','Delivered','Cancelled'];if(!allowed.includes(req.body.status))return res.status(400).json({message:'Invalid status'});try{const p=await db();const r=await p.request().input('oid',sql.VarChar(30),req.params.id).input('status',sql.VarChar(30),req.body.status).query('UPDATE Orders SET Status=@status WHERE OrderID=@oid; SELECT OrderID id,Status status FROM Orders WHERE OrderID=@oid');if(!r.recordsets[1]?.length)return res.status(404).json({message:'Order not found'});res.json(r.recordsets[1][0]);}catch(e){res.status(500).json({message:'Status update failed'});} });

app.patch('/api/orders/:id/payment',auth,async(req,res)=>{if(req.user.role!=='Customer')return res.status(403).json({message:'Customer account required'});try{const p=await db();const r=await p.request().input('oid',sql.VarChar(30),req.params.id).input('cid',sql.Int,req.user.id).input('ref',sql.VarChar(100),req.body.reference||`DEMO-${Date.now()}`).query(`UPDATE Payments SET PaymentStatus='Paid',Reference=@ref,PaidAt=SYSUTCDATETIME() WHERE OrderID=@oid AND EXISTS(SELECT 1 FROM Orders WHERE OrderID=@oid AND CustomerID=@cid); SELECT OrderID id,PaymentStatus paymentStatus,Reference reference FROM Payments WHERE OrderID=@oid`); if(!r.recordsets[1]?.length)return res.status(404).json({message:'Order not found'});res.json(r.recordsets[1][0]);}catch(e){res.status(500).json({message:'Payment update failed'});} });

app.post('/api/contact',auth,async(req,res)=>{try{const p=await db();await p.request().input('cid',sql.Int,req.user.role==='Customer'?req.user.id:null).input('subject',sql.VarChar(150),req.body.subject||'General enquiry').input('message',sql.VarChar(1000),req.body.message||'').query('INSERT INTO ContactMessages(CustomerID,Subject,Message) VALUES(@cid,@subject,@message)');res.status(201).json({message:'Message sent'});}catch(e){res.status(500).json({message:'Message could not be sent'});} });

app.get('/api/admin/stats',auth,admin,async(req,res)=>{try{const p=await db();const r=await p.request().query("SELECT (SELECT COUNT(*) FROM Customers) customers,(SELECT COUNT(*) FROM Orders) orders,(SELECT COUNT(*) FROM Orders WHERE Status='Pending') pending,(SELECT ISNULL(SUM(Amount),0) FROM Payments WHERE PaymentStatus='Paid') revenue");res.json(r.recordset[0]);}catch(e){res.status(500).json({message:'Unable to load statistics'});} });

async function ensureDemoAdmin(){
  try{const p=await db(); const email='admin@inandout.local'; const r=await p.request().input('email',sql.VarChar(150),email).query('SELECT AdminID FROM Admins WHERE Email=@email'); if(!r.recordset.length){const hash=await bcrypt.hash('Admin@123',12); await p.request().input('name',sql.VarChar(120),'In & Out Administrator').input('email',sql.VarChar(150),email).input('hash',sql.VarChar(255),hash).query('INSERT INTO Admins(FullName,Email,PasswordHash) VALUES(@name,@email,@hash)'); console.log('Demo admin created: admin@inandout.local / Admin@123');}}catch(e){console.warn('Demo admin bootstrap skipped:',e.message);}
}
ensureDemoAdmin().finally(()=>app.listen(port,()=>console.log(`In & Out Laundry API running on port ${port}`)));
