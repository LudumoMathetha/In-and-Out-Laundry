USE InAndOutLaundry;
GO
INSERT INTO Services(ServiceName,Unit,Price) VALUES
('Wash & Fold','kg',35.00),
('Dry Cleaning','item',45.00),
('Ironing','item',25.00),
('Express','kg',55.00);
GO
-- The API creates the demo admin securely on first startup: admin@inandout.local / Admin@123
GO
