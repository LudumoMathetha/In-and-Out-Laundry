# In & Out Laundry – Full-Stack Student Project

This upgraded project is based on the XISD6329 Task 1 requirements. It contains a professional responsive website, an Android/Kotlin starter application, a REST API, SQL schema/seed scripts and testing structure.

## Structure
- `website/` – HTML, CSS and JavaScript website
- `backend/` – Node.js/Express REST API prototype
- `database/` – SQL Server schema and seed data
- `mobile_app/InAndOutLaundry/` – Android Studio Kotlin project
- `tests/` – testing notes
- `docs/` – project documentation and original prototype

## Website
Open `website/index.html` with VS Code Live Server.

## API
```bash
cd backend
npm install
npm start
```
API runs on port 3000.

## Android
Open `mobile_app/InAndOutLaundry` in Android Studio. The app currently demonstrates the customer home/booking flow and is structured for REST API integration.

## Important assignment note
The current website still uses Local Storage as a demonstration fallback. For the final XISD6329 submission, connect website and Android to the shared API and persistent database. The task document states that Local Storage is temporary and must be replaced by the shared backend/API and database.
