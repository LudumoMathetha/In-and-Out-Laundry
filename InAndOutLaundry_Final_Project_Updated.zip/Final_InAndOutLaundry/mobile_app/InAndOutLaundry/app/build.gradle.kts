plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace="com.inandoutlaundry.app"; compileSdk=35
 defaultConfig { applicationId="com.inandoutlaundry.app"; minSdk=24; targetSdk=35; versionCode=1; versionName="1.0" }
}

dependencies { implementation("androidx.core:core-ktx:1.15.0"); implementation("androidx.appcompat:appcompat:1.7.0"); implementation("com.google.android.material:material:1.12.0"); implementation("androidx.constraintlayout:constraintlayout:2.2.0"); implementation("com.squareup.retrofit2:retrofit:2.11.0"); implementation("com.squareup.retrofit2:converter-gson:2.11.0") }
