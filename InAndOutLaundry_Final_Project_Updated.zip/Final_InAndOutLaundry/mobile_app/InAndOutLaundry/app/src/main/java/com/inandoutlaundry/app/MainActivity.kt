package com.inandoutlaundry.app

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<Button>(R.id.bookButton).setOnClickListener {
            findViewById<TextView>(R.id.statusText).text = "Booking flow selected — connect this action to the shared API."
        }
        findViewById<Button>(R.id.trackButton).setOnClickListener {
            findViewById<TextView>(R.id.statusText).text = "Tracking selected — enter an order ID in the final tracking screen."
        }
    }
}
