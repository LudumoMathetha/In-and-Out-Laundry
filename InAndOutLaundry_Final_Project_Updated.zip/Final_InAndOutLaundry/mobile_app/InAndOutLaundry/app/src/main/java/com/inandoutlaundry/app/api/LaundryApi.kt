package com.inandoutlaundry.app.api

import retrofit2.http.GET
import retrofit2.http.Path

data class Order(val id:String,val status:String,val service:String,val quantity:Double)
interface LaundryApi { @GET("api/orders/{id}") suspend fun getOrder(@Path("id") id:String):Order }
