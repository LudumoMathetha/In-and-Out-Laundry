# In & Out Laundry – Test Plan

| ID | Area | Test | Expected result |
|---|---|---|---|
| T01 | API | GET /api/health | API reports healthy database connection |
| T02 | Registration | Create valid customer | Account is stored and JWT is returned |
| T03 | Registration | Reuse email | 409 response and clear message |
| T04 | Login | Valid customer credentials | Customer token/session is created |
| T05 | Login | Invalid credentials | 401 response |
| T06 | Booking | Submit valid booking | Order and pending payment are stored |
| T07 | Tracking | Request existing order | Correct order/status returned |
| T08 | Payment | Confirm demo payment | Payment becomes Paid with reference |
| T09 | Admin | Update order status | Status persists in database |
| T10 | Authorisation | Customer calls admin endpoint | 403 response |
| T11 | UI | Mobile viewport | Navigation and forms remain usable |
| T12 | Validation | Missing required fields | Browser/API validation prevents invalid submission |

Automated API/integration tests should be connected to the CI pipeline before final submission.
