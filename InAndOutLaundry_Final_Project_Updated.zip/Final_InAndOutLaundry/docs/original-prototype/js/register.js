// In & Out Laundry — register.js
// Student comments by Ludumo Mathetha and Chulumanco Iviwe Ngongomana
// Handles simple registration using Local Storage (student project requirement)

console.log("register loaded");

// Utility: read users array from localStorage
function readUsers(){
	return JSON.parse(localStorage.getItem('iol_users') || '[]');
}

// Utility: write users array to localStorage
function writeUsers(users){
	localStorage.setItem('iol_users', JSON.stringify(users));
}

document.addEventListener('DOMContentLoaded', function(){
	const form = document.getElementById('registerForm');
	const msg = document.getElementById('registerMsg');
	if(!form) return;

	form.addEventListener('submit', function(e){
		e.preventDefault();
		const name = document.getElementById('name').value.trim();
		const email = document.getElementById('email').value.trim().toLowerCase();
		const password = document.getElementById('password').value;

		const users = readUsers();
		// Check for existing email
		if(users.find(u => u.email === email)){
			msg.textContent = 'An account with that email already exists.';
			return;
		}

		// Create user object and persist
		const user = {id: Date.now(), name, email, password};
		users.push(user);
		writeUsers(users);

		// Provide feedback and redirect to login after brief delay
		msg.textContent = 'Registration successful — redirecting to login...';
		setTimeout(()=> location.href = 'login.html', 1200);
	});
});
