// In & Out Laundry — admin.js
// Admin dashboard functionality: view and update order statuses (Local Storage)

console.log("admin loaded");

function readOrders() {
    return JSON.parse(localStorage.getItem('iol_orders') || '[]');
}

function writeOrders(orders) {
    localStorage.setItem('iol_orders', JSON.stringify(orders));
}

function buildTable(orders) {
    if (!orders || orders.length === 0) return '<div class="muted">No orders yet.</div>';

    let html = '<table class="table table-striped"><thead><tr><th>Order ID</th><th>Customer</th><th>Service</th><th>Qty</th><th>Status</th><th>Created</th></tr></thead><tbody>';
    orders.forEach((o, idx) => {
        html += `<tr data-idx="${idx}"><td>${o.id}</td><td>${o.name}<br><small class="muted">${o.email}</small></td><td>${o.service}</td><td>${o.quantity}</td><td>` +
            `<select class="form-select form-select-sm status-select" data-idx="${idx}">` +
            ['Pending', 'In Progress', 'Completed', 'Cancelled'].map(s => `<option ${s === o.status ? 'selected' : ''}>${s}</option>`).join('') +
            `</select></td><td>${new Date(o.createdAt).toLocaleString()}</td></tr>`;
    });
    html += '</tbody></table>';
    return html;
}

document.addEventListener('DOMContentLoaded', function () {
    const container = document.getElementById('ordersContainer');
    if (!container) return;

    const adminLoginBtn = document.getElementById('adminLoginBtn');
    const adminLogoutBtn = document.getElementById('adminLogoutBtn');
    const adminLoginForm = document.getElementById('adminLoginForm');
    const adminLoginMsg = document.getElementById('adminLoginMsg');

    function isAdminLogged() {
        const a = JSON.parse(localStorage.getItem('iol_admin') || 'null');
        return a && a.username === 'Chulumanco';
    }

    function setAdminSession(username) {
        localStorage.setItem('iol_admin', JSON.stringify({ username }));
    }

    function clearAdminSession() {
        localStorage.removeItem('iol_admin');
    }

    function attachStatusHandlers() {
        container.querySelectorAll('.status-select').forEach(select => {
            select.addEventListener('change', function () {
                if (!isAdminLogged()) {
                    alert('Only admins can update order statuses.');
                    return;
                }
                const idx = parseInt(this.dataset.idx, 10);
                const ordersNow = readOrders();
                ordersNow[idx].status = this.value;
                writeOrders(ordersNow);
            });
        });
    }

    function refresh() {
        const orders = readOrders();
        if (!isAdminLogged()) {
            container.innerHTML = '<div class="muted">Please sign in as admin to manage orders.</div>';
            adminLoginBtn.classList.remove('d-none');
            adminLogoutBtn.classList.add('d-none');
            return;
        }
        container.innerHTML = buildTable(orders);
        attachStatusHandlers();
        adminLoginBtn.classList.add('d-none');
        adminLogoutBtn.classList.remove('d-none');
    }

    // Handle admin login form
    if (adminLoginForm) {
        adminLoginForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const user = document.getElementById('adminUser').value.trim();
            const pass = document.getElementById('adminPass').value;
            // Check provided credentials (student-specified)
            if (user === 'Chulumanco' && pass === 'Iviwe@26') {
                setAdminSession(user);
                adminLoginMsg.textContent = 'Signed in';
                // close modal if bootstrap present
                try { const modalEl = document.getElementById('adminLoginModal'); const modal = bootstrap.Modal.getInstance(modalEl); if (modal) modal.hide(); } catch (e) { }
                refresh();
            } else {
                adminLoginMsg.textContent = 'Invalid admin credentials';
            }
        });
    }

    // Handle logout
    if (adminLogoutBtn) {
        adminLogoutBtn.addEventListener('click', function () {
            clearAdminSession();
            refresh();
        });
    }

    refresh();
});
