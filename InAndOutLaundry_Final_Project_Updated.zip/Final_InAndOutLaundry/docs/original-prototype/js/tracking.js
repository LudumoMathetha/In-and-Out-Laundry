// In & Out Laundry — tracking.js
// Allows customers to find orders by order ID or email (Local Storage search)

console.log("tracking loaded");

function readOrders(){
	return JSON.parse(localStorage.getItem('iol_orders') || '[]');
}

function renderOrderCard(order){
	return `
		<div class="card p-3 mb-2">
			<div class="d-flex justify-content-between">
				<div>
					<strong>${order.id}</strong> — ${order.service} <br>
					<small class="muted">${order.name} • ${order.email}</small>
				</div>
				<div class="text-end">
					<div class="badge bg-info text-dark">${order.status}</div>
					<div class="muted" style="font-size:0.85rem">${new Date(order.createdAt).toLocaleString()}</div>
				</div>
			</div>
		</div>`;
}

document.addEventListener('DOMContentLoaded', function(){
	const form = document.getElementById('trackForm');
	const results = document.getElementById('trackResults');
	if(!form) return;

	form.addEventListener('submit', function(e){
		e.preventDefault();
		const id = document.getElementById('orderId').value.trim();
		const email = document.getElementById('email').value.trim().toLowerCase();
		const orders = readOrders();

		let found = [];
		if(id){
			found = orders.filter(o => o.id.toLowerCase() === id.toLowerCase());
		} else if(email){
			found = orders.filter(o => o.email === email);
		}

		if(found.length === 0){
			results.innerHTML = '<div class="muted">No matching orders found.</div>';
			return;
		}

		results.innerHTML = found.map(renderOrderCard).join('\n');
	});
});
