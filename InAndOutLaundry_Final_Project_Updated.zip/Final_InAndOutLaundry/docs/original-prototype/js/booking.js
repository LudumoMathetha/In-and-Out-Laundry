// In & Out Laundry — booking.js
// Booking system: creates orders with generated IDs and saves to Local Storage

console.log("booking loaded");

function readOrders(){
	return JSON.parse(localStorage.getItem('iol_orders') || '[]');
}

function writeOrders(orders){
	localStorage.setItem('iol_orders', JSON.stringify(orders));
}

function getCurrentUser(){
	return JSON.parse(localStorage.getItem('iol_currentUser') || 'null');
}

function generateOrderId(){
	// Short unique ID: IOL-<base36 timestamp>-<3digit>
	return 'IOL-' + Date.now().toString(36).toUpperCase() + '-' + Math.floor(100 + Math.random()*900);
}

document.addEventListener('DOMContentLoaded', function(){
	const form = document.getElementById('bookingForm');
	const msg = document.getElementById('bookingMsg');
	if(!form) return;

	// Prefill from logged in user if available
	const cur = getCurrentUser();
	if(cur){
		const nameEl = document.getElementById('name');
		const emailEl = document.getElementById('email');
		if(nameEl) nameEl.value = cur.name || '';
		if(emailEl) emailEl.value = cur.email || '';
	}

	form.addEventListener('submit', function(e){
		e.preventDefault();
		const name = document.getElementById('name').value.trim();
		const email = document.getElementById('email').value.trim().toLowerCase();
		const service = document.getElementById('service').value;
		const quantity = parseFloat(document.getElementById('quantity').value) || 1;

		const orders = readOrders();
		const order = {
			id: generateOrderId(),
			name, email, service, quantity,
			status: 'Pending',
			createdAt: new Date().toISOString()
		};
		orders.push(order);
		writeOrders(orders);

		msg.innerHTML = `Booking placed. Your order ID is <strong>${order.id}</strong>. Use it to track your order.`;
		form.reset();
		// Keep name/email prefilled for convenience
		if(cur){
			document.getElementById('name').value = cur.name || '';
			document.getElementById('email').value = cur.email || '';
		}
	});
});
