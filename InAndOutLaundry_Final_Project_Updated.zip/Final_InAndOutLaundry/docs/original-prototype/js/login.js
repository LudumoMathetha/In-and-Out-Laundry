// In & Out Laundry — login.js
// Simple login using Local Storage for demonstration

console.log("login loaded");

function readUsers(){
	return JSON.parse(localStorage.getItem('iol_users') || '[]');
}

function setCurrentUser(user){
	localStorage.setItem('iol_currentUser', JSON.stringify(user));
}

document.addEventListener('DOMContentLoaded', function(){
	const form = document.getElementById('loginForm');
	const msg = document.getElementById('loginMsg');
	if(!form) return;

	form.addEventListener('submit', function(e){
		e.preventDefault();
		const email = document.getElementById('email').value.trim().toLowerCase();
		const password = document.getElementById('password').value;
		const users = readUsers();

		const user = users.find(u => u.email === email && u.password === password);
		if(!user){
			msg.textContent = 'Invalid credentials. Please try again.';
			return;
		}

		// Successful login
		setCurrentUser({id: user.id, name: user.name, email: user.email});
		msg.textContent = 'Login successful — redirecting to booking...';
		setTimeout(()=> location.href = 'booking.html', 800);
	});
});
