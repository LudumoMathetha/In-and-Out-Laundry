Open with Visual Studio Code and run with Live Server.

Project: In & Out Laundry — student WIL project

Team:
- Ludumo Mathetha
- Chulumanco Iviwe Ngongomana

Features:
- Responsive UI with Bootstrap
- Local Storage based registration & login
- Booking system with generated order IDs
- Order tracking and admin dashboard to update statuses

To run: open the folder in VS Code and use Live Server or open index.html in a browser.