# In & Out Laundry – Implementation Notes

## Updated implementation
The website has been upgraded from the prototype's Local Storage workflow to a REST API architecture. Customer registration, login, bookings, order tracking, payment confirmation and admin status updates now call the API.

The Android application is kept as a separate Kotlin project and is intended to consume the same API. The SQL Server schema provides the persistent relational database for Customers, Admins, Services, Orders, Payments and ContactMessages.

## Run order
1. Create the `InAndOutLaundry` database by running `database/schema.sql` in SQL Server Management Studio.
2. Run `database/seed.sql` to insert the service catalogue.
3. Copy `backend/.env.example` to `backend/.env` and enter SQL Server credentials.
4. In `backend/`, run `npm install` then `npm start`.
5. Open `website/index.html` using VS Code Live Server.
6. Register a customer account and create a booking.
7. Demo admin: `admin@inandout.local` / `Admin@123`.

## API endpoints
- GET `/api/health`
- GET `/api/services`
- POST `/api/auth/register`
- POST `/api/auth/login`
- GET `/api/me`
- POST `/api/orders`
- GET `/api/orders`
- GET `/api/orders/:id`
- PATCH `/api/orders/:id/status` (admin)
- PATCH `/api/orders/:id/payment` (customer demo payment)
- POST `/api/contact`
- GET `/api/admin/stats` (admin)

## Security note
Passwords are hashed with bcrypt and sessions use JWT access tokens. The demo payment button only records a payment status; it is not a real payment gateway.

## Assignment alignment
The implementation follows the supplied Task 1 structure: website, mobile app, database, tests and documentation. GitHub/Azure DevOps setup and automated pipeline evidence still need to be completed in the team's external repositories.
